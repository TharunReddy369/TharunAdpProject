package com.example.eletterdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ELetterdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
