package com.example.eletterdemo.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.logging.Logger;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.verification.VerificationModeFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.eletterdemo.dao.CandidateDao;
import com.example.eletterdemo.dao.EletterHrRepository;
import com.example.eletterdemo.dao.PdfRepository;
import com.example.eletterdemo.dto.CombinedResult;
import com.example.eletterdemo.dto.HrDTO;
import com.example.eletterdemo.entity.Candidate;
import com.example.eletterdemo.entity.HR;
import com.example.eletterdemo.entity.RequestPayload;
import com.example.eletterdemo.service.CandidateService;
import com.example.eletterdemo.service.ICandidateService;
import com.example.eletterdemo.service.PdfService;

@SpringBootTest
public class CandidateControllerTest {
@InjectMocks
CandidateController controller;
@Mock
CandidateService service;
@Mock
PdfService pdfservice;
@Mock 
CandidateController candidatecontroller;
@MockBean
private EletterHrRepository repo;

@Mock
RequestPayload payload;

List<Candidate> candidates;
Candidate candidate;
	
Logger logger = Logger.getLogger(CandidateControllerTest.class.getName()); 

//private HR satya , raju;
//
//@TestConfiguration
//static class CredentialsServiceImplTestContextConfiguration {
//    @Bean
//    public ICandidateService credentialService() {
//        return new CandidateService();
//    }
//}
//
//@Autowired
//private CandidateService credentialService;
//
//@MockBean
//private EletterHrRepository credentialRepository;
//
//@BeforeEach
//public void setUp() {
//    satya = new HR(1000009 , "satya@gmail.com" , "Satya@123");
//    raju = new HR(1000010, "raju@gmail.com" , "Raju@123");
//    
//    List<Integer> allIds = Arrays.asList(satya.getId() , raju.getId());
//    
//    Mockito.when(credentialRepository.findById(satya.getId())).thenReturn(Optional.of(satya));
//    Mockito.when(credentialRepository.findById(-1)).thenThrow(new NoSuchElementException());
//    //Mockito.when(credentialRepository.allIds()).thenReturn(allIds);
//}
//
//@AfterEach
//public void cleanup() {
//    satya=null;
//    raju=null;
//}
//
//private void verifyFindByIdIsCalledOnce(Integer id) {
//    Mockito.verify(credentialRepository , VerificationModeFactory.times(1)).findById(id);
//    Mockito.reset(credentialRepository);
//}
//
//private void verifyAllIdsIsCalledOnce() {
//    Mockito.verify(credentialRepository , VerificationModeFactory.times(1)).allIds();
//    Mockito.reset(credentialRepository);
//}
//
//@Test
//public void whenGetById_thenReturnCredentials() {
//    Integer id = satya.getId();
//    HrDTO found = credentialService.getById(id);
//    verifyFindByIdIsCalledOnce(id);
//    assertThat(found.getId()).isEqualTo(id);
//}
//
//@Test
//public void whenInvalidId_thenReturnError() {
//    assertThrows(NoSuchElementException.class,()->{credentialService.getById(-1);});
//    verifyFindByIdIsCalledOnce(-1);
//}
//
//@Test
//public void whenGetAllIds_thenReturnAllIds() {
//    List<HrDTO> ids = credentialService.getAllIds();
//    verifyAllIdsIsCalledOnce();
//    assertThat(ids).isEqualTo(ids);
//}

@Test
public void getcandidatespreview() {
	candidates = new ArrayList<>();
	candidates.add(new Candidate(87927, "arjun", "kumar", 60000, "lbnagar","developer", new Date(2023,11,25), 9843764989L, "arjunk8@gmail.com",new Date(2023,11,20),"hyderabad",'S'));
	ResponseEntity<List<Candidate>> res = controller.getcandidatespreview();
	assertEquals(HttpStatus.OK, res.getStatusCode());
	
}

@Test
public void getcandidates() {
	candidates = new ArrayList<>();
	candidates.add(new Candidate(87927, "arjun", "kumar", 60000, "lbnagar","developer", new Date(2023,11,25), 9843764989L, "arjunk8@gmail.com",new Date(2023,11,20),"hyderabad",'S'));
	when(service.getCandidates()).thenReturn(candidates);
	ResponseEntity<List<Candidate>> res = controller.getcandidates();
	assertEquals(HttpStatus.OK, res.getStatusCode());
}

@Test
public void getUnsentList() {
	candidates = new ArrayList<>();
	candidates.add(new Candidate(87927, "arjun", "kumar", 60000, "lbnagar","developer", new Date(2023,11,25), 9843764989L, "arjunk8@gmail.com",new Date(2023,11,20),"hyderabad",'S'));
	ResponseEntity<List<Candidate>> res = controller.getUnsentList();
	assertEquals(HttpStatus.OK, res.getStatusCode());
}

@Test
public void getAllcandidates() {
	candidates = new ArrayList<>();
	boolean val = true;
	candidates.add(new Candidate(87927, "arjun", "kumar", 60000, "lbnagar","developer", new Date(2023,11,25), 9843764989L, "arjunk8@gmail.com",new Date(2023,11,20),"hyderabad",'S'));
	controller.getAllcandidates(payload);
	assertEquals(val, true);
}

@Test
public void mywordToPdf() throws Exception {
	boolean val = true;
	MockitoAnnotations.initMocks(this);
	Mockito.doNothing().when(pdfservice).savePdfToDatabase(anyString());
	controller.mywordToPdf(87927, new Candidate(87927, "arjun", "kumar", 60000, "lbnagar","developer", new Date(2023,11,25), 9843764989L, "arjunk8@gmail.com",new Date(2023,11,20),"hyderabad",'S'));
	assertEquals(val, true);
			
			
}

@Test
public void findUnsent() {
	candidates = new ArrayList<>();
	candidates.add(new Candidate(87927, "arjun", "kumar", 60000, "lbnagar","developer", new Date(2023,11,25), 9843764989L, "arjunk8@gmail.com",new Date(2023,11,20),"hyderabad",'S'));
	ResponseEntity<Map> res = controller.findUnsent();
	assertEquals(HttpStatus.OK, res.getStatusCode());
}

@Test
public void getRecordByMonth() {
	candidates = new ArrayList<>();
	candidates.add(new Candidate(87927, "arjun", "kumar", 60000, "lbnagar","developer", new Date(2023,11,25), 9843764989L, "arjunk8@gmail.com",new Date(2023,11,20),"hyderabad",'S'));
	List<Object[]> res = controller.getRecordByMonth();
	assertEquals(res.size(),0);
}

//@Test
//public void getRecordByMonthMap() {
//	candidates = new ArrayList<>();
//	candidates.add(new Candidate(87927, "arjun", "kumar", 60000, "lbnagar","developer", new Date(2023,11,25), 9843764989L, "arjunk8@gmail.com",new Date(2023,11,20),"hyderabad",'S'));
//	Map<String, Long> res = controller.getRecordbyMonth();
//	assertEquals(res.get("Jan"),0);
//}

@Test
public void getRecordbydojMonth() {
	candidates = new ArrayList<>();
	candidates.add(new Candidate(87927, "arjun", "kumar", 60000, "lbnagar","developer", new Date(2023,11,25), 9843764989L, "arjunk8@gmail.com",new Date(2023,11,20),"hyderabad",'S'));
	Map<String, Long> res = controller.getRecordbydojMonth();
	assertEquals(res.get("Jan"), 0);
}

@Test
public void getCombinedResult() {
candidates = new ArrayList<>();
candidates.add(new Candidate(87927, "arjun", "kumar", 60000, "lbnagar","developer", new Date(2023,11,25), 9843764989L, "arjunk8@gmail.com",new Date(2023,11,20),"hyderabad",'S'));
ResponseEntity<CombinedResult> res = controller.getCombinedResult();
assertEquals(HttpStatus.OK, res.getStatusCode());
}

@SuppressWarnings("deprecation")
@Test
public void savePdfToDatabase() throws IOException {
	MockitoAnnotations.initMocks(this);
	Mockito.doNothing().when(pdfservice).savePdfToDatabase(anyString());
	String result = controller.savePdfToDatabase("C:\\Users\\polamadv\\Downloads\\neweletter\\Temp_Offer_letter.docx");
	assertEquals("PDF saved to database successfully!",result);
}

@Test
public void savePdfToDatabaseExceptionCase() throws IOException {
	String filepath = "invalid.doc";
	doThrow(new IOException("Simulated IOException")).when(pdfservice).savePdfToDatabase(anyString());
	String result = controller.savePdfToDatabase(filepath);
	assertTrue(result.startsWith("Error saving PDF to database: "));
}

@ParameterizedTest
@ValueSource(ints = {1,2,3,4,5,6,7,8,9,10,11,12})
public void getMonthName(int month) {
	assertEquals("Jan",controller.getMonthName(1));
}


@Test
public void getInvalidMonthName() {
	assertEquals("Invalid Month", controller.getMonthName(30));
}


	


}