package com.example.eletterdemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.eletterdemo.entity.PdfEntity;

public interface PdfRepository extends JpaRepository<PdfEntity, Long> {
}