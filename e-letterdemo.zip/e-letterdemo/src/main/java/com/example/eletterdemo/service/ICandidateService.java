package com.example.eletterdemo.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.example.eletterdemo.dto.HrDTO;
import com.example.eletterdemo.dto.MonthEntry;
import com.example.eletterdemo.entity.Candidate;

import fr.opensagres.poi.xwpf.converter.core.XWPFConverterException;

public interface ICandidateService {
    public List<Candidate> getCandidates();
    public int findByUnsent();
    public int findBySent();
    public List<Object[]> getRecordCountByMonth();
    public List<MonthEntry> getByMonth();
    public List<MonthEntry> getBydojMonth();
    public HrDTO getById(Integer id);
    public List<HrDTO> getAllIds();
    
    ByteArrayInputStream convertHtmlToPdf(String htmlContent);
    public void createPdfFromString(String content, String outputPath);
    public void createPdfFromString(List<String> content, String outputPath);
    public List<Candidate> findByStatus();
    
    public void generateReplacedDocx(List<Candidate> cand, String type) throws IOException ;

//	public List<RecordCountDto> getByDto();

}
