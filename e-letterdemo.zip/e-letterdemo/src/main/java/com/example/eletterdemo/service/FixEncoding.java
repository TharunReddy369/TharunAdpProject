package com.example.eletterdemo.service;

import org.apache.pdfbox.pdmodel.font.encoding.WinAnsiEncoding;

public class FixEncoding extends WinAnsiEncoding {
    public   String remove(String bufstr) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < bufstr.length(); i++) {
            if (WinAnsiEncoding.INSTANCE.contains(bufstr.charAt(i))) {
                b.append(bufstr.charAt(i));
            }
        }
        return b.toString();
    }}
