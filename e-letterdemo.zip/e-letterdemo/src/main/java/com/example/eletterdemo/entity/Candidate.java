package com.example.eletterdemo.entity;

import java.sql.Date;

import jakarta.persistence.Entity;

import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="season2_batch1_team3_candidates")
public class Candidate {
    @Id
    int id;
    String firstname;
    String lastname;
    int salary;
    String address;
    String designation;
    Date doj;
    long contactnumber;
    String emailid;
    Date sentdate;
    String worklocation;
    char status;
    public Candidate() {}
    public Candidate(int id, String firstname, String lastname,int salary, String address, String designation, Date doj,
            long contactnumber, String emailid, Date sentdate, String worklocation, char status) {
        super();
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.salary = salary;
        this.address = address;
        this.designation = designation;
        this.doj = doj;
        this.contactnumber = contactnumber;
        this.emailid = emailid;
        this.sentdate = sentdate;
        this.worklocation = worklocation;
        this.status = status;
    }
    @Override
    public String toString() {
        return "Candidate [id=" + id + ", firstname=" + firstname + ", lastname=" + lastname + ", address=" + address
                + ", designation=" + designation + ", doj=" + doj + ", contactnumber=" + contactnumber + ", emailid="
                + emailid + ", sentdate=" + sentdate + ", worklocation=" + worklocation + ", status=" + status + "]";
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getFirstname() {
        return firstname;
    }
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }
    public String getLastname() {
        return lastname;
    }
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getDesignation() {
        return designation;
    }
    public void setDesignation(String designation) {
        this.designation = designation;
    }
    public Date getDoj() {
        return doj;
    }
    public void setDoj(Date doj) {
        this.doj = doj;
    }
    public long getContactnumber() {
        return contactnumber;
    }
    public void setContactnumber(long contactnumber) {
        this.contactnumber = contactnumber;
    }
    public String getEmailid() {
        return emailid;
    }
    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }
    public Date getSentdate() {
        return sentdate;
    }
    public void setSentdate(Date sentdate) {
        this.sentdate = sentdate;
    }
    public String getWorklocation() {
        return worklocation;
    }
    public void setWorklocation(String worklocation) {
        this.worklocation = worklocation;
    }
    public char getStatus() {
        return status;
    }
    public void setStatus(char status) {
        this.status = status;
    }
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
    
    
    
    
    

}
