package com.example.eletterdemo.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.eletterdemo.entity.HR;

@Repository
public interface EletterHrRepository extends JpaRepository<HR, Integer>{

    @Query(value = "SELECT * FROM TEAM3_CREDENTIALS ",nativeQuery = true)
    public List<HR> allIds();
}

