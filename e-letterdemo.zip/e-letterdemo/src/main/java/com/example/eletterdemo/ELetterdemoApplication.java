package com.example.eletterdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ELetterdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ELetterdemoApplication.class, args);
	}

}
