package com.example.eletterdemo.entity;



import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="team3_credentials")
public class HR {
    
    @Id
    private Integer Id;
    private String Email;
    private String pwd;



      public HR() {
         
      }

    public HR(Integer id, String email, String pwd) {
        super();
        Id = id;
        Email = email;
        this.pwd = pwd;
    }
    
    

    public Integer getId() {
        return Id;
    }



    public void setId(Integer id) {
        Id = id;
    }



    public String getEmail() {
        return Email;
    }


    public void setEmail(String email) {
        Email = email;
    }



    public String getPwd() {
        return pwd;
    }



    public void setPwd(String pwd) {
        this.pwd = pwd;
    }



    @Override
    public String toString() {
        return "HR [Id=" + Id + ", Email=" + Email + ", pwd=" + pwd + "]";
    }
      
      
      
      
}
