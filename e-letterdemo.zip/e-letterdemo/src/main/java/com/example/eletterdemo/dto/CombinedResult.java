package com.example.eletterdemo.dto;

import java.util.Map;

public class CombinedResult {
	
	private Map<String, Long> bySentDate;
	private Map<String, Long> byDoj;
	
	public CombinedResult() {
		
	}
	
	public CombinedResult(Map<String, Long> bySentDate, Map<String, Long> byDoj) {
		this.bySentDate = bySentDate;
		this.byDoj = byDoj;
	}

	public Map<String, Long> getBySentDate() {
		return bySentDate;
	}

	public void setBySentDate(Map<String, Long> bySentDate) {
		this.bySentDate = bySentDate;
	}

	public Map<String, Long> getByDoj() {
		return byDoj;
	}

	public void setByDoj(Map<String, Long> byDoj) {
		this.byDoj = byDoj;
	}
	

}
