package com.example.eletterdemo.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.example.eletterdemo.dao.CandidateDao;
import com.example.eletterdemo.dao.EletterHrRepository;
import com.example.eletterdemo.dto.HrDTO;
import com.example.eletterdemo.dto.MonthEntry;
import com.example.eletterdemo.entity.Candidate;
import com.example.eletterdemo.mapper.HrMapper;

import fr.opensagres.poi.xwpf.converter.core.XWPFConverterException;



@Service
public class CandidateService implements ICandidateService {

    @Autowired
    CandidateDao dao;
    
    @Autowired
    EletterHrRepository repo;
    


    @Override
    public List<Candidate> getCandidates() {
        // TODO Auto-generated method stub
        return dao.findAll();
    }

	@Override
	public int findByUnsent() {
		// TODO Auto-generated method stub
		return dao.findByUnsent();
	}
	
	@Override
	public int findBySent() {
		// TODO Auto-generated method stub
		return dao.findBySent();
	}

	@Override
	public List<Object[]> getRecordCountByMonth() {
		// TODO Auto-generated method stub
		return dao.getRecordCountByMonth();
	}

	
	@Override
	public List<MonthEntry> getByMonth() {
		// TODO Auto-generated method stub
		List<Map<String, Object>> list =  dao.getMonth();
		List<MonthEntry> monthEntries = new ArrayList<>();
		for(Map<String, Object> entry : list ){
			MonthEntry monthEntry = new MonthEntry();
			monthEntry.setMonthName((String) entry.get("monthname"));
			monthEntry.setTotal((BigDecimal) entry.get("total"));
			monthEntries.add(monthEntry);
		}
		return monthEntries;
	}

	@Override
	public List<MonthEntry> getBydojMonth() {
		// TODO Auto-generated method stub
		List<Map<String, Object>> list =  dao.getdojMonth();
		List<MonthEntry> monthEntries = new ArrayList<>();
		for(Map<String, Object> entry : list ){
			MonthEntry monthEntry = new MonthEntry();
			monthEntry.setMonthName((String) entry.get("monthname"));
			monthEntry.setTotal((BigDecimal) entry.get("total"));
			monthEntries.add(monthEntry);
		}
		return monthEntries;
	}

	@Override
    public HrDTO getById(Integer id) {
        HrDTO needed = HrMapper.mapToHrDTO(repo.findById(id).get());
        return needed;
    }

    @Override
    public List<HrDTO> getAllIds() {
        return repo.allIds().stream().map((ele)-> HrMapper.mapToHrDTO(ele)).collect(Collectors.toList());
    }
	
    @Override
    public ByteArrayInputStream convertHtmlToPdf(String htmlContent) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        ITextRenderer renderer = new ITextRenderer();
        renderer.setDocumentFromString(htmlContent);
        renderer.layout();
        renderer.createPDF(outputStream, false);
        renderer.finishPDF();
        ByteArrayInputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
        return inputStream;
    }
    
    public void createPdfFromString(String content, String outputPath) {}
    
    public void createPdfFromString(List<String> content, String outputPath) {
        try (PDDocument document = new PDDocument()) {
        PDPage page = new PDPage();
        document.addPage(page);

        try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
        float yPosition=700;
        for(String ele:content) {
        contentStream.beginText();
        contentStream.newLineAtOffset(50, yPosition); // Adjust coordinates as needed
        contentStream.showText(ele);
        contentStream.endText();
        yPosition -=15;
        }
        }

        document.save(outputPath);
        } catch (IOException e) {
        e.printStackTrace(); // Handle exception appropriately in your application
        }
        }

	@Override
	public List<Candidate> findByStatus() {
		// TODO Auto-generated method stub
		return dao.findByStatus();
	}
	
	
//	public void generateReplacedDocx(List<Candidate> cand) throws IOException {
//        FileInputStream file;
//        for(Candidate c: cand) {
//            file = new FileInputStream("C:\\Users\\vermakun\\Downloads\\neweletter\\Template_Offer_letter.docx");
//        XWPFDocument demo = new XWPFDocument(file);
//        
//        file.close();
//        List<XWPFParagraph> paragraph=demo.getParagraphs();
//        
//    
//        
//        for(XWPFParagraph para:paragraph) {
//             
//             replacePlaceholder(para,"name",c.getFirstname()+" "+c.getLastname());
//             replacePlaceholder(para,"role",c.getDesignation());
//             replacePlaceholder(para,"doj","11/24/2023");
//             replacePlaceholder(para,"salary",Integer.toString(c.getSalary()));
//            
//            
//            
//    
//            
//            
//                            
//        }
//    
//     FileOutputStream fos=new FileOutputStream("C:\\Users\\vermakun\\Downloads\\neweletter\\NewOffer_letter"+c.getId()+".docx") ;
//        
//        demo.write(fos);
//        fos.close();
//        }
//        
//        
//    }
	
	
	public void generateReplacedDocx(List<Candidate> cand, String type) throws IOException {
        FileInputStream file;
        if(type.equals("offer_letter")) {
        	
        
        for(Candidate c: cand) {
            if(c.getAddress().equals("hyderabad")) {
            file = new FileInputStream("C:\\Users\\vermakun\\Downloads\\neweletter\\Template_Offer_letter.docx");
        XWPFDocument demo = new XWPFDocument(file);
        
        file.close();
        List<XWPFParagraph> paragraph=demo.getParagraphs();
        
    
        
        for(XWPFParagraph para:paragraph) {
             
             replacePlaceholder(para,"name",c.getFirstname()+" "+c.getLastname());
             replacePlaceholder(para,"${Role}",c.getDesignation());
             replacePlaceholder(para,"doj","11/24/2023");
             replacePlaceholder(para,"${Package}","700000");
            
            
            
    
            
            
                            
        }
    
     FileOutputStream fos=new FileOutputStream("C:\\Users\\vermakun\\Downloads\\neweletter\\NewOffer_letter"+c.getId()+".docx") ;
        
        demo.write(fos);
        fos.close();
        }
            else {
                file = new FileInputStream("C:\\Users\\vermakun\\Downloads\\neweletter\\Template_Offer_letter2.docx");
                XWPFDocument demo = new XWPFDocument(file);
                
                file.close();
                List<XWPFParagraph> paragraph=demo.getParagraphs();
                
            
                
                for(XWPFParagraph para:paragraph) {
                     
                     replacePlaceholder(para,"name",c.getFirstname()+" "+c.getLastname());
                     replacePlaceholder(para,"${Role}",c.getDesignation());
                     replacePlaceholder(para,"doj","11/24/2023");
                     replacePlaceholder(para,"${Package}","700000");
                    
                    
                    
            
                    
                    
                                    
                }
            
             FileOutputStream fos=new FileOutputStream("C:\\Users\\vermakun\\Downloads\\neweletter\\NewOffer_letter"+c.getId()+".docx") ;
                
                demo.write(fos);
                fos.close();
            }
        }
        }
        else {
        	   for(Candidate c: cand) {
                   file = new FileInputStream("C:\\Users\\vermakun\\Downloads\\neweletter\\Bonus_Template.docx");
               XWPFDocument demo = new XWPFDocument(file);
               
               file.close();
               List<XWPFParagraph> paragraph=demo.getParagraphs();
               
           
               
               for(XWPFParagraph para:paragraph) {
                    
                    replacePlaceholder(para,"name",c.getFirstname()+" "+c.getLastname());
                    replacePlaceholder(para,"role",c.getDesignation());
                    replacePlaceholder(para,"date",String.valueOf(c.getSentdate()));
                    replacePlaceholder(para,"salary",Integer.toString(c.getSalary()));
                   
                                   
               }
           
            FileOutputStream fos=new FileOutputStream("C:\\Users\\vermakun\\Downloads\\neweletter\\NewOffer_letter"+c.getId()+".docx") ;
               
               demo.write(fos);
               fos.close();
        }}
        
        
    }

    private static void replacePlaceholder(XWPFParagraph paragraph, String targetWord, String replacement) {
          String text=paragraph.getText();
                if(text.contains(targetWord))
                {
                    paragraph.getRuns().forEach(run ->{
                        String runText=run.getText(0);
                      
                        if(runText!=null && runText.contains(targetWord)) {
                            run.setText(runText.replace(targetWord, replacement+"\n"),0);
                        }
                    });
                }}

   
}
