package com.example.eletterdemo.entity;

import java.util.*;

public class Sample {
	
	ArrayList<Integer> emp;

	public ArrayList<Integer> getEmp() {
		return emp;
	}

	public void setEmp(ArrayList<Integer> emp) {
		this.emp = emp;
	}

	public Sample() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Sample(ArrayList<Integer> emp) {
		super();
		this.emp = emp;
	}

	@Override
	public String toString() {
		return "Sample [emp=" + emp + "]";
	}
}
