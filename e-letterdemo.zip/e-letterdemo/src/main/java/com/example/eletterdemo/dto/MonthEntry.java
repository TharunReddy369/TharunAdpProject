package com.example.eletterdemo.dto;

import java.math.BigDecimal;

public class MonthEntry {
	
	private String monthName;
	private BigDecimal total;
	public MonthEntry() {
		// TODO Auto-generated constructor stub
	}
	public MonthEntry(String month, BigDecimal count) {
		super();
		this.monthName = monthName;
		this.total = total;
	}
	public String getMonthName() {
		return monthName;
	}
	public void setMonthName(String monthName) {
		this.monthName = monthName;
	}
	public BigDecimal getTotal() {
		return total;
	}
	public void setTotal(BigDecimal total) {
		this.total = total;
	}
	


}
