package com.example.eletterdemo.entity;

import java.util.List;

public class RequestPayload {
	
	private List<Candidate> totallist;
	private String type;
	
	public RequestPayload() {
		
	}
	
	

	public RequestPayload(List<Candidate> totallist, String type) {
		super();
		this.totallist = totallist;
		this.type = type;
	}
	
	



	@Override
	public String toString() {
		return "RequestPayload [totallist=" + totallist + ", type=" + type + "]";
	}



	public List<Candidate> getTotallist() {
		return totallist;
	}

	public void setTotallist(List<Candidate> totallist) {
		this.totallist = totallist;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	

}
