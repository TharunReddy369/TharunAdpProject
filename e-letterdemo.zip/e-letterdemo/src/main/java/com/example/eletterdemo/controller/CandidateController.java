package com.example.eletterdemo.controller;


import java.io.File;

import com.example.eletterdemo.entity.RequestPayload;
import java.io.FileInputStream;



import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.example.eletterdemo.service.CandidateService;
import com.example.eletterdemo.service.FixEncoding;
import com.example.eletterdemo.service.ICandidateService;
import com.example.eletterdemo.service.PdfService;
//import com.fasterxml.jackson.core.util.RequestPayload;
//import com.fasterxml.jackson.core.util.RequestPayload;

import fr.opensagres.poi.xwpf.converter.core.XWPFConverterException;
import fr.opensagres.poi.xwpf.converter.pdf.PdfConverter;
import fr.opensagres.poi.xwpf.converter.pdf.PdfOptions;

import com.example.eletterdemo.dao.CandidateDao;
import com.example.eletterdemo.dto.CombinedResult;
import com.example.eletterdemo.dto.HrDTO;
import com.example.eletterdemo.dto.MonthEntry;
import com.example.eletterdemo.entity.Candidate;

@RestController
@RequestMapping("/candidates")
public class CandidateController {
    
    @Autowired
    ICandidateService service;
    
    @Autowired
    PdfService pdfService;
    
    @Autowired
    CandidateDao dao;
    
    List<Candidate> previewList=new ArrayList<>();
    
    @CrossOrigin("*")
    @GetMapping("/getpreview")
    public ResponseEntity<List<Candidate>> getcandidatespreview() {
        //System.out.println(service.getCandidates());
        System.out.println("preview...");
        System.out.println(previewList);
        return new ResponseEntity<>(previewList,HttpStatus.OK);
        
    }

  
    
    @CrossOrigin("*")
    @GetMapping("/get")
    public ResponseEntity<List<Candidate>> getcandidates() {
        //System.out.println(service.getCandidates());
        return new ResponseEntity<>(service.getCandidates(),HttpStatus.OK);
        
    }
    
    @CrossOrigin("*")
    @GetMapping("/get-unsent-list")
    public ResponseEntity<List<Candidate>> getUnsentList() {
        //System.out.println(service.getCandidates());
        return new ResponseEntity<>(service.findByStatus(),HttpStatus.OK);
        
    }
    
    
    @CrossOrigin("*")
    @PostMapping("/getlist")
    public void getAllcandidates(@RequestBody RequestPayload payload ) {
        int i=0;
        //System.out.println(service.getCandidates());
        List<Candidate> totalList = payload.getTotallist();
        System.out.println("type"+payload.getType());
        String type = payload.getType();
        System.out.println(payload);
        previewList=totalList;
        for(Candidate ele:totalList) {
            System.out.println(i+"-"+ele);
            i++;
        }
            try {
                service.generateReplacedDocx(totalList, type);

                //service.updateStatusToSent(candidate.getId());
            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            for(Candidate c:totalList) {
                try {
                    mywordToPdf(c.getId(),c);
                    dao.save(new Candidate(c.getId(),c.getFirstname(),c.getLastname(),c.getSalary(),c.getAddress(),c.getDesignation(),c.getDoj(),c.getContactnumber(),c.getEmailid(),c.getSentdate(),c.getWorklocation(),'S'));
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                
            }
    }
    
    
    public  void mywordToPdf(int id, Candidate c) throws Exception{
        String docPath="C:\\Users\\vermakun\\Downloads\\neweletter\\NewOffer_letter"+id+".docx";
        String pdfPath="C:\\Users\\vermakun\\Downloads\\pdfletter\\"+c.getFirstname()+" "+c.getLastname()+".pdf";
        try {
            InputStream docFile = new FileInputStream(new File(docPath));
            XWPFDocument doc = new XWPFDocument(docFile);
            PdfOptions pdfOptions = PdfOptions.create();
            OutputStream out = new FileOutputStream(new File(pdfPath));
            PdfConverter.getInstance().convert(doc, out, pdfOptions);
            doc.close();
            out.close();
            savePdfToDatabase("C:\\Users\\vermakun\\Downloads\\pdfletter\\"+c.getFirstname()+" "+c.getLastname()+".pdf");
            System.out.println("Done");
        }
        catch(Exception e) {
            e.printStackTrace();
        }

    


}
    

    
    @CrossOrigin("*")
    @GetMapping("/analytics")
    public ResponseEntity<Map> findUnsent() {
//    	System.out.println(service.findByUnsent());
    	Map<String, Integer> map = new LinkedHashMap<>();
    	int sent =  service.findBySent();
    	int unsent =  service.findByUnsent();
    	map.put("sent", sent);
    	map.put("unsent", unsent);
    	
		return new ResponseEntity<>(map, HttpStatus.OK);
    }
    
    @GetMapping("/by-month")
    @CrossOrigin("*")
    public List<Object[]> getRecordByMonth() {
    	return service.getRecordCountByMonth();
    }
    
    
    @CrossOrigin("*")
    @GetMapping("/eletter/letter/{id}")
    public ResponseEntity<HrDTO> getCredbyId(@PathVariable("id") Integer id) {
        HrDTO creds = service.getById(id);
        return new ResponseEntity<>(creds, HttpStatus.OK);
    }
    
    @CrossOrigin("*")
    @GetMapping("/eletter/allcreds")
    public ResponseEntity<List<HrDTO>> getAllCredIds() {
        List<HrDTO> all = service.getAllIds();
        return new ResponseEntity<>(all, HttpStatus.OK);
    }
    
    
    
    @GetMapping("/by-sentdate")
    @CrossOrigin("*")
    public Map<String, Long> getBySentDate() {
    	List<MonthEntry> list = service.getByMonth();
    	Map<String, Long> res = new LinkedHashMap<>();
    	for(int month = 1; month <= 12; month++) {
    		res.put(getMonthName(month), 0L);
    	}
    	for(MonthEntry entry : list) {
    		res.put(entry.getMonthName(), entry.getTotal().longValue());
    	}
		return res;
    }
    
    @GetMapping("/by-doj")
    @CrossOrigin("*")
    public Map<String, Long> getRecordbydojMonth() {
    	List<MonthEntry> list = service.getBydojMonth();
    	Map<String, Long> res = new LinkedHashMap<>();
    	for(int month = 1; month <= 12; month++) {
    		res.put(getMonthName(month), 0L);
    	}
    	for(MonthEntry entry : list) {
    		res.put(entry.getMonthName(), entry.getTotal().longValue());
    	}
		return res;
    }
    
    @CrossOrigin("*")
    @GetMapping("/combined-results")
    public ResponseEntity<CombinedResult> getCombinedResult() {
    	Map<String, Long> bySentDateResult = getBySentDate();
    	Map<String, Long> byDojResult = getRecordbydojMonth();
    	return new ResponseEntity<>(new CombinedResult(bySentDateResult, byDojResult), HttpStatus.OK);
    }
    
    public ResponseEntity<String> readDocxFile(Candidate c) throws FileNotFoundException, IOException{
        
        
        try(FileInputStream fis=new FileInputStream("C:/Users/vermakun/Downloads/baeldung.docx");
            XWPFDocument document=new XWPFDocument(fis)){
            StringBuilder text=new StringBuilder();
            List<String> l=new ArrayList<>();
            //List<String> l=new ArrayList<>();
            document.getParagraphs().forEach(paragraph -> 
            {
            replaceWordInParagraph(paragraph,"name",c.getFirstname()+" "+c.getLastname());
            replaceWordInParagraph(paragraph,"salary","70000");
            replaceWordInParagraph(paragraph,"role",c.getDesignation());
            replaceWordInParagraph(paragraph,"unid",Integer.toString(c.getId()));


            System.out.println("my paragraph is "+paragraph.getText());
            int il=paragraph.getText().length();
            String str=paragraph.getText();
            int i=0;
             boolean flag=false;
             int maxlength=97;
             List<String> newl;
             if(paragraph.getText().length()>maxlength) {
                 
                  newl=splitString(str,maxlength);
                  l.addAll(newl);
                  for(String ele:newl) {
                      System.out.println("MMM"+ele);
                  }
             }
             else {
                 l.add(paragraph.getText());
             }
             
            
             text.append(paragraph.getText()).append("<br/>");
            });
            String newText=text.toString();
            FixEncoding f=new FixEncoding();
            List<String> nl=new ArrayList<>();
            for(String ele:l) {
            nl.add(f.remove(ele));
            }
            generatePdf(nl,c);
            System.out.println(newText);
            
            
        return ResponseEntity.ok(newText);

        }
                
    }
 public void replaceWordInParagraph(XWPFParagraph paragraph,String targetWord,String replacement) {
        String text=paragraph.getText();
        System.out.println("sss..."+targetWord+" "+replacement);

        if(text.contains(targetWord))
        {
            System.out.println("trrrruu");
            paragraph.getRuns().forEach(run ->{
                String runText=run.getText(0);
                System.out.println(runText+" .........");
                if(runText!=null && runText.contains(targetWord)) {
                    System.out.println("avvv"+targetWord+" "+replacement);
                    run.setText(runText.replace(targetWord, replacement+"\n"),0);
                }
            });
        }
    }



    public void generatePdf(List<String> content,Candidate c) {
    //String content = "Hello, this is the content of the PDF!";
    //String outputPath = "path/to/your/output.pdf";
    String outputPath = "C:/Users/vermakun/Downloads/e-letter-pdf/"+c.getId()+".pdf";
    service.createPdfFromString(content, outputPath);
    savePdfToDatabase(outputPath);
    System.out.println( "PDF generated successfully at " + outputPath);
    }
     public static List<String> splitString(String input,int maxLinelength) {
           String[] words=input.split("\\s+");
           StringBuilder currentLine =new StringBuilder();
           List<String> result=new ArrayList<>();
           for(String word:words) {
               if(currentLine.length()+word.length()<= maxLinelength) {
                   currentLine.append(word).append(" ");
               }
               else {
                   result.add(currentLine.toString().trim());
                   currentLine=new StringBuilder(word+" ");
               }
           }
           if(currentLine.length()>0) {
               result.add(currentLine.toString().trim());
           }
           return result;
       }
     
     public String savePdfToDatabase(String filePath) {
         try {
             pdfService.savePdfToDatabase(filePath);
             return "PDF saved to database successfully!";
         } catch (IOException e) {
             e.printStackTrace();
             return "Error saving PDF to database: " + e.getMessage();
         }
     }
    
    
    
    public String getMonthName(int  month) {
    	String[] monthNames = {
    			"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    	};
    	try {
    		int numericMonth = month;
    		
    		if(numericMonth >= 1 && numericMonth <= 12) {
    			return monthNames[numericMonth - 1];
    		} else {
    			return "Invalid Month";
    		}
    	}
    	catch (Exception e){
    		System.out.println(e);
    	}
		return null;
    	
    }
    
   

}
