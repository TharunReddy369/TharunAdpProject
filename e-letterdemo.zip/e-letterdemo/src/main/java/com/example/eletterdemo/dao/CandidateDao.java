package com.example.eletterdemo.dao;


import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.eletterdemo.dto.MonthEntry;
import com.example.eletterdemo.entity.Candidate;


@Repository
public interface CandidateDao extends JpaRepository<Candidate,Integer>{
		
	@Query(nativeQuery=true,  value="select count(*) from season2_batch1_team3_candidates where status='N'")
	public int findByUnsent();
	
	@Query(nativeQuery=true,  value="select *  from season2_batch1_team3_candidates where status='N'")
	public List<Candidate> findByStatus();
	
	
	@Query(nativeQuery=true, value="select count(*) from season2_batch1_team3_candidates where status='S'")
	public int findBySent();
	
	@Query(nativeQuery=true, value="select extract( month from sentdate ) as month, count(*) as count from season2_batch1_team3_candidates  group by extract (month from sentdate )")
	List<Object[]> getRecordCountByMonth();
	
	@Query(nativeQuery=true, value="select to_char(sentdate, 'Mon') as monthname ,count(*) as total from season2_batch1_team3_candidates group by to_char(sentdate, 'Mon'), extract (month from sentdate )")
	List<Map<String, Object>> getMonth();
	
	@Query(nativeQuery=true, value="select to_char(doj, 'Mon') as monthname ,count(*) as total from season2_batch1_team3_candidates group by to_char(doj, 'Mon'), extract (month from doj )")
	List<Map<String, Object>> getdojMonth();
	
	
    
	
	
}