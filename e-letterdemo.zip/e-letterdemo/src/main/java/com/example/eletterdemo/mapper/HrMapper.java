package com.example.eletterdemo.mapper;

import com.example.eletterdemo.dto.HrDTO;
import com.example.eletterdemo.entity.HR;

public class HrMapper {

    
      public static HR mapToHR(HrDTO dto) {
            HR entity = new HR(
                    dto.getId() ,
                    dto.getEmail() ,
                    dto.getPwd()
            );
            return entity;
        }
        
        public static HrDTO mapToHrDTO(HR entity) {
            HrDTO dto = new HrDTO(
                    entity.getId() ,
                    entity.getEmail() ,
                    entity.getPwd()
            );
            return dto;
        }
}
