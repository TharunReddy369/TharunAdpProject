package com.example.eletterdemo.dto;



public class HrDTO {

    private Integer Id;
    private String Email;
    private String pwd;
    
    
    
    
    
    
    public HrDTO(Integer id, String email, String pwd) {
        super();
        Id = id;
        Email = email;
        this.pwd = pwd;
    }
    
    
    
    public Integer getId() {
        return Id;
    }
    public void setId(Integer id) {
        Id = id;
    }
    public String getEmail() {
        return Email;
    }
    public void setEmail(String email) {
        Email = email;
    }
    public String getPwd() {
        return pwd;
    }
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
    
    
    @Override
    public String toString() {
        return "HrDTO [Id=" + Id + ", Email=" + Email + ", pwd=" + pwd + "]";
    }

    
    
    
    
}