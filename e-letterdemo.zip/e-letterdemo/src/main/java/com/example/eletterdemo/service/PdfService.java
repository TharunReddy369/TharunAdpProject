package com.example.eletterdemo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.eletterdemo.dao.PdfRepository;
import com.example.eletterdemo.entity.PdfEntity;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
public class PdfService {

    private final PdfRepository pdfRepository;

    @Autowired
    public PdfService(PdfRepository pdfRepository) {
        this.pdfRepository = pdfRepository;
    }

    public void savePdfToDatabase(String filePath) throws IOException {
        byte[] pdfData = readPdfFile(filePath);
        PdfEntity pdfEntity = new PdfEntity();
        pdfEntity.setPdfData(pdfData);
        pdfRepository.save(pdfEntity);
    }

    private byte[] readPdfFile(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        return Files.readAllBytes(path);
    }
}